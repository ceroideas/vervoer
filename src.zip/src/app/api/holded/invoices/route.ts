import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth-config'
import { HoldedClient } from '@/holded/client'

// GET - Obtener facturas de Holded
export async function GET() {
  try {
    // Verificar autenticación
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ message: 'No autorizado' }, { status: 401 })
    }

    const holded = new HoldedClient()
    const invoices = await holded.getInvoices()

    return NextResponse.json({
      success: true,
      invoices: invoices
    })
  } catch (error) {
    console.error('Error obteniendo facturas de Holded:', error)
    return NextResponse.json({
      success: false,
      error: 'Error al obtener facturas'
    }, { status: 500 })
  }
}

// POST - Crear nueva factura en Holded
export async function POST(req: NextRequest) {
  try {
    // Verificar autenticación
    const session = await getServerSession(authOptions)
    if (!session?.user) {
      return NextResponse.json({ message: 'No autorizado' }, { status: 401 })
    }

    const body = await req.json()
    console.log('📥 Datos recibidos del frontend:', JSON.stringify(body, null, 2))
    
    const { 
      contactId, 
      contactName,
      date, 
      dueDate, 
      currency, 
      notes, 
      items,
      docType = 'invoice',
      invoiceNum,
      applyContactDefaults = true,
      approveDoc = true // Siempre aprobar documentos
    } = body

    // Validar datos requeridos
    if (!contactId || !date || !items || items.length === 0) {
      return NextResponse.json({
        success: false,
        error: 'Faltan datos requeridos'
      }, { status: 400 })
    }

    // Log de fechas para debug
    console.log('📅 Fechas recibidas:')
    console.log('  - date:', date, 'tipo:', typeof date)
    console.log('  - dueDate:', dueDate, 'tipo:', typeof dueDate)
    console.log('  - new Date(date):', new Date(date))
    console.log('  - new Date(date).getTime():', new Date(date).getTime())

    const holded = new HoldedClient()
    
    // Calcular fechas correctamente según documentación oficial
    const issueDate = new Date(date)
    
    // Validar que la fecha sea válida
    if (isNaN(issueDate.getTime())) {
      return NextResponse.json({
        success: false,
        error: 'Fecha inválida proporcionada'
      }, { status: 400 })
    }
    
    // Ajustar la hora a las 12:00 para evitar problemas con medianoche
    issueDate.setHours(12, 0, 0, 0)
    
    // Holded espera timestamps en SEGUNDOS (Unix timestamp)
    const dateTimestamp = Math.floor(issueDate.getTime() / 1000)
    
    console.log('📅 Fecha final:')
    console.log('  - Fecha original:', date)
    console.log('  - Fecha parseada:', issueDate.toISOString())
    console.log('  - Timestamp (segundos):', dateTimestamp)
    console.log('  - Timestamp (milisegundos):', issueDate.getTime())
    
    // Debug adicional: verificar si el contacto existe y obtener su nombre
    console.log('🔍 Verificando contacto en Holded...')
    let resolvedContactName = ''
    try {
      const contact = await holded.getContact(contactId)
      resolvedContactName = contact.name
      console.log('✅ Contacto encontrado:', resolvedContactName)
    } catch (contactError) {
      console.error('❌ Error verificando contacto:', contactError)
      return NextResponse.json({
        success: false,
        error: 'Contacto no encontrado en Holded'
      }, { status: 400 })
    }
    
    // Crear el documento en Holded usando la estructura exacta de la documentación oficial
    const documentData = {
      applyContactDefaults: true,
      contactId,
      contactName: resolvedContactName,
      desc: notes || '',
      date: dateTimestamp, // Timestamp en segundos (Unix timestamp)
      notes: notes || '',
      currency: currency || 'EUR',
      invoiceNum: invoiceNum || '',
      approveDoc: true, // Siempre aprobar documentos automáticamente
      items: items.map((item: any) => ({
        name: item.description,
        desc: item.description,
        units: item.quantity,
        subtotal: item.price, // Precio unitario, Holded calculará el total (units * subtotal)
        discount: 0,
        tax: item.tax || 21,
        taxes: [`${item.tax || 21}`]
      }))
    }
    
    console.log('📄 Datos del documento a enviar a Holded:', JSON.stringify(documentData, null, 2))

    const newDocument = await holded.createDocument(docType as 'invoice' | 'waybill', documentData)

    return NextResponse.json({
      success: true,
      document: newDocument,
      message: `${docType === 'invoice' ? 'Factura' : 'Albarán'} creado exitosamente`
    })
  } catch (error) {
    console.error('Error creando documento en Holded:', error)
    return NextResponse.json({
      success: false,
      error: 'Error al crear el documento'
    }, { status: 500 })
  }
}