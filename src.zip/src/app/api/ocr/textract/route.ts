import { NextRequest, NextResponse } from 'next/server'
import { TextractClient, DetectDocumentTextCommand } from '@aws-sdk/client-textract'

export const runtime = 'nodejs'

interface ExtractedData {
  documentType: 'invoice' | 'delivery_note'
  documentNumber?: string
  date?: string
  supplier?: {
    name?: string
    address?: string
    taxId?: string
  }
  items?: Array<{
    reference?: string
    description?: string
    quantity?: number
    unitPrice?: number
    totalPrice?: number
  }>
  totals?: {
    subtotal?: number
    tax?: number
    total?: number
  }
}

function extractDataFromText(text: string): ExtractedData {
  const normalizedText = text.replace(/\u00A0/g, ' ')
  const lines = normalizedText
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)

  const parseEuro = (raw: string): number | undefined => {
    let s = raw.replace(/[€$\s]/g, '')
    const sign = s.startsWith('-') ? -1 : 1
    s = s.replace(/^[+-]/, '')
    if (/,/.test(s) && /\./.test(s)) {
      s = s.replace(/\./g, '').replace(',', '.')
    } else if (/,/.test(s)) {
      s = s.replace(',', '.')
    }
    const num = Number(s)
    return Number.isFinite(num) ? sign * num : undefined
  }
  const amountRegex = /[€$]?\s*[+-]?\d{1,3}(?:[\.,]\d{3})*(?:[\.,]\d{2})|[€$]?\s*[+-]?\d+(?:[\.,]\d{2})/g

  const extracted: ExtractedData = {
    documentType: normalizedText.toLowerCase().includes('factura') ? 'invoice' : 'delivery_note',
    items: [],
    totals: {}
  }

  const documentNumberMatch = normalizedText.match(/(?:FACTURA|ALBARÁN|ALBARAN)\s*(?:Nº?|NÚMERO?|NUMERO?)?\s*:?\s*([A-Z0-9\-_\/]+)/i)
  if (documentNumberMatch) {
    extracted.documentNumber = documentNumberMatch[1]
  }

  const dateMatch = normalizedText.match(/(?:FECHA|DATE)\s*:?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/i)
  if (dateMatch) {
    extracted.date = dateMatch[1]
  }

  const supplierKeywords = ['PROVEEDOR', 'EMISOR', 'VENDEDOR', 'EMPRESA', 'COMPAÑÍA', 'COMPAÑIA']
  for (const keyword of supplierKeywords) {
    const supplierMatch = normalizedText.match(new RegExp(`${keyword}\\s*:?\\s*([^\\n]+)`, 'i'))
    if (supplierMatch) {
      extracted.supplier = { name: supplierMatch[1].trim() }
      break
    }
  }

  const itemLines = lines.filter(line => {
    const hasNumbers = /\d+/.test(line)
    const hasPrice = amountRegex.test(line)
    const isNotHeader = !line.match(/^(FACTURA|ALBARÁN|ALBARAN|TOTAL|SUBTOTAL|IVA)/i)
    return hasNumbers && (hasPrice || isNotHeader) && line.length > 10
  })

  for (const line of itemLines.slice(0, 50)) {
    const item: any = {}

    const quantityMatch = line.match(/(\d+(?:[,.]\d+)?)\s*(?:x|un|ud|uds?|pcs?)/i)
    if (quantityMatch) {
      item.quantity = parseFloat(quantityMatch[1].replace(',', '.'))
    }

    const amounts = Array.from(line.matchAll(amountRegex)).map(m => m[0])
    if (amounts.length >= 1) {
      const last = amounts[amounts.length - 1]
      const parsedTotal = parseEuro(last)
      if (parsedTotal !== undefined) item.totalPrice = parsedTotal
      if (amounts.length >= 2) {
        const first = amounts[0]
        const parsedUnit = parseEuro(first)
        if (parsedUnit !== undefined) item.unitPrice = parsedUnit
      }
    }

    const description = line
      .replace(amountRegex, '')
      .replace(/\d+(?:[,.]\d+)?\s*(?:x|un|ud|uds?|pcs?)/i, '')
      .replace(/^\s*[-_]\s*/, '')
      .replace(/\s{2,}/g, ' ')
      .trim()
    if (description.length > 3) item.description = description

    const referenceMatch = line.match(/([A-Z0-9]{3,10})/)
    if (referenceMatch) item.reference = referenceMatch[1]

    if (item.description || item.quantity || item.unitPrice || item.totalPrice) {
      extracted.items?.push(item)
    }
  }

  const totalMatch = normalizedText.match(/TOTAL\s*:?\s*[€$]?\s*([+-]?\d{1,3}(?:[\.,]\d{3})*(?:[\.,]\d{2})|[+-]?\d+(?:[\.,]\d{2}))/i)
  if (totalMatch) {
    const v = parseEuro(totalMatch[1])
    if (v !== undefined) extracted.totals!.total = v
  }
  const subtotalMatch = normalizedText.match(/SUBTOTAL\s*:?\s*[€$]?\s*([+-]?\d{1,3}(?:[\.,]\d{3})*(?:[\.,]\d{2})|[+-]?\d+(?:[\.,]\d{2}))/i)
  if (subtotalMatch) {
    const v = parseEuro(subtotalMatch[1])
    if (v !== undefined) extracted.totals!.subtotal = v
  }

  return extracted
}

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()
    const file = formData.get('file') as File | null
    if (!file) {
      return NextResponse.json({ error: 'No se envió ningún archivo.' }, { status: 400 })
    }

    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/tiff']
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({
        error: 'Tipo de archivo no soportado por Textract síncrono. Use JPG, PNG, WEBP o TIFF. Para PDF use el OCR local o suba a S3 para análisis asíncrono.'
      }, { status: 400 })
    }

    const arrayBuffer = await file.arrayBuffer()
    const bytes = new Uint8Array(arrayBuffer)

    const client = new TextractClient({ region: process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || 'eu-west-1' })
    const command = new DetectDocumentTextCommand({
      Document: { Bytes: bytes }
    })
    const response = await client.send(command)

    const lines = (response.Blocks || [])
      .filter(b => b.BlockType === 'LINE' && b.Text)
      .map(b => b.Text as string)
    const text = lines.join('\n')

    const extractedData = extractDataFromText(text)
    return NextResponse.json({
      text,
      extractedData,
      success: true,
      engine: 'aws-textract'
    })
  } catch (error) {
    return NextResponse.json({ error: 'Error procesando con Textract', details: String(error) }, { status: 500 })
  }
}


