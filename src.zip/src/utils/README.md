# Utilidades generales
Aquí se colocarán funciones y helpers reutilizables en el proyecto. 