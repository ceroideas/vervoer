"use client"

import { useState, useEffect } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Plus, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

interface CreateProductModalProps {
  onProductCreated?: () => void;
  prefillData?: {
    name?: string;
    description?: string;
    price?: number;
    cost?: number;
    sku?: string;
    tax?: number;
    stock?: number;
    weight?: number;
    barcode?: string;
    tags?: string;
  };
}

export function CreateProductModal({ onProductCreated, prefillData }: CreateProductModalProps) {
  const [open, setOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: prefillData?.name || '',
    description: prefillData?.description || '',
    price: prefillData?.price?.toString() || '',
    cost: prefillData?.cost?.toString() || '',
    sku: prefillData?.sku || '',
    tax: prefillData?.tax?.toString() || '0',
    stock: prefillData?.stock?.toString() || '0',
    weight: prefillData?.weight?.toString() || '0',
    barcode: prefillData?.barcode || '',
    tags: prefillData?.tags || ''
  })

  // Actualizar formulario cuando cambien los datos de pre-relleno
  useEffect(() => {
    if (prefillData) {
      setFormData({
        name: prefillData.name || '',
        description: prefillData.description || '',
        price: prefillData.price?.toString() || '',
        cost: prefillData.cost?.toString() || '',
        sku: prefillData.sku || '',
        tax: prefillData.tax?.toString() || '0',
        stock: prefillData.stock?.toString() || '0',
        weight: prefillData.weight?.toString() || '0',
        barcode: prefillData.barcode || '',
        tags: prefillData.tags || ''
      })
    }
  }, [prefillData])

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Preparar datos para enviar según documentación oficial de Holded
      const productData = {
        kind: 'simple', // Campo obligatorio según Holded
        name: formData.name,
        desc: formData.description, // Campo 'desc' según documentación
        price: parseFloat(formData.price),
        tax: parseFloat(formData.tax),
        cost: formData.cost ? parseFloat(formData.cost) : 0,
        calculatecost: formData.cost ? parseFloat(formData.cost) : 0,
        purchasePrice: formData.cost ? parseFloat(formData.cost) : 0,
        tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()) : [],
        barcode: formData.barcode,
        sku: formData.sku,
        weight: parseFloat(formData.weight),
        stock: parseInt(formData.stock),
      }

      const response = await fetch('/api/holded/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(productData),
      })

      const result = await response.json()

      if (result.success) {
        toast.success('Producto creado exitosamente en Holded')
        setOpen(false)
        setFormData({
          name: '',
          description: '',
          price: '',
          cost: '',
          sku: '',
          tax: '0',
          stock: '0',
          weight: '0',
          barcode: '',
          tags: ''
        })
        onProductCreated?.()
      } else {
        toast.error(`Error: ${result.error}`)
      }
    } catch (error) {
      console.error('Error creando producto:', error)
      toast.error('Error al crear el producto')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Nuevo Producto
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Crear Nuevo Producto en Holded</DialogTitle>
          <DialogDescription>
            Completa los campos para crear un nuevo producto en tu inventario de Holded.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Información Básica */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Información Básica</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Nombre del producto"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="sku">SKU</Label>
                <Input
                  id="sku"
                  value={formData.sku}
                  onChange={(e) => handleInputChange('sku', e.target.value)}
                  placeholder="Código SKU"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Descripción del producto"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price">Precio de Venta *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => handleInputChange('price', e.target.value)}
                  placeholder="0.00"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cost">Precio de Costo</Label>
                <Input
                  id="cost"
                  type="number"
                  step="0.01"
                  value={formData.cost}
                  onChange={(e) => handleInputChange('cost', e.target.value)}
                  placeholder="0.00"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="tax">Impuesto (%)</Label>
                <Input
                  id="tax"
                  type="number"
                  step="0.01"
                  value={formData.tax}
                  onChange={(e) => handleInputChange('tax', e.target.value)}
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Información Adicional */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Información Adicional</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="stock">Stock Inicial</Label>
                <Input
                  id="stock"
                  type="number"
                  value={formData.stock}
                  onChange={(e) => handleInputChange('stock', e.target.value)}
                  placeholder="0"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="weight">Peso (kg)</Label>
                <Input
                  id="weight"
                  type="number"
                  step="0.01"
                  value={formData.weight}
                  onChange={(e) => handleInputChange('weight', e.target.value)}
                  placeholder="0.00"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="barcode">Código de Barras</Label>
                <Input
                  id="barcode"
                  value={formData.barcode}
                  onChange={(e) => handleInputChange('barcode', e.target.value)}
                  placeholder="Código de barras"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="tags">Etiquetas</Label>
                <Input
                  id="tags"
                  value={formData.tags}
                  onChange={(e) => handleInputChange('tags', e.target.value)}
                  placeholder="Etiquetas separadas por comas"
                />
              </div>
            </div>
          </div>

          {/* Botones */}
          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={isLoading}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Creando...
                </>
              ) : (
                <>
                  <Plus className="h-4 w-4 mr-2" />
                  Crear Producto
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
