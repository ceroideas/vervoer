import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { AuthService } from '@/lib/auth'

// GET /api/documents/[id] - Obtener un documento específico
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Verificar autenticación
    const token = request.cookies.get('auth-token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '')
    
    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      )
    }

    const currentUser = await AuthService.getCurrentUser(token)
    if (!currentUser) {
      return NextResponse.json(
        { success: false, error: 'Token inválido' },
        { status: 401 }
      )
    }

    const documentId = params.id

    // Obtener el documento con sus relaciones
    const document = await prisma.document.findFirst({
      where: {
        id: documentId,
        userId: currentUser.id // Solo documentos del usuario autenticado
      },
      include: {
        supplier: true,
        items: {
          include: {
            product: true
          }
        },
        processedBy: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    })

    if (!document) {
      return NextResponse.json(
        { success: false, error: 'Documento no encontrado' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: { document }
    })

  } catch (error) {
    console.error('Error obteniendo documento:', error)
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

// DELETE /api/documents/[id] - Eliminar un documento
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Verificar autenticación
    const token = request.cookies.get('auth-token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '')
    
    if (!token) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      )
    }

    const currentUser = await AuthService.getCurrentUser(token)
    if (!currentUser) {
      return NextResponse.json(
        { success: false, error: 'Token inválido' },
        { status: 401 }
      )
    }

    const documentId = params.id

    // Verificar que el documento existe y pertenece al usuario
    const existingDocument = await prisma.document.findFirst({
      where: {
        id: documentId,
        userId: currentUser.id
      }
    })

    if (!existingDocument) {
      return NextResponse.json(
        { success: false, error: 'Documento no encontrado' },
        { status: 404 }
      )
    }

    // Eliminar el documento (los items se eliminan automáticamente por CASCADE)
    await prisma.document.delete({
      where: {
        id: documentId
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Documento eliminado correctamente'
    })

  } catch (error) {
    console.error('Error eliminando documento:', error)
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
