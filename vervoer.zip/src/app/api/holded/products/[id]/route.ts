import { NextRequest, NextResponse } from 'next/server';
import { holdedClient } from '@/holded/client';

// Obtener un producto específico
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`📦 Obteniendo producto de Holded con ID: ${params.id}`);
    
    const product = await holdedClient.getProduct(params.id);
    
    console.log(`✅ Producto obtenido: ${product.name}`);
    
    return NextResponse.json({
      success: true,
      product: product,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error(`❌ Error obteniendo producto de Holded:`, error);
    
    return NextResponse.json({
      success: false,
      error: 'Error obteniendo producto de Holded',
      details: String(error),
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

// Actualizar un producto específico
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`📦 Actualizando producto de Holded con ID: ${params.id}`);
    
    const body = await req.json();
    const { name, description, price, cost, sku, category } = body;

    // Validar campos requeridos
    if (!name || !price) {
      return NextResponse.json({
        success: false,
        error: 'Nombre y precio son campos requeridos',
        timestamp: new Date().toISOString()
      }, { status: 400 });
    }

    // Preparar datos del producto según la documentación oficial de Holded
    const productData = {
      kind: 'simple', // Campo obligatorio según Holded
      name,
      desc: description || '', // Campo 'desc' según documentación
      price: parseFloat(price),
      tax: 0, // Impuesto por defecto
      cost: cost ? parseFloat(cost) : 0,
      calculatecost: cost ? parseFloat(cost) : 0, // Campo adicional según documentación
      purchasePrice: cost ? parseFloat(cost) : 0, // Campo adicional según documentación
      tags: [], // Array de strings según documentación
      barcode: '', // Código de barras
      sku: sku || '',
      weight: 0, // Peso
      stock: 0, // Stock inicial
    };

    console.log('📊 Datos del producto a actualizar:', JSON.stringify(productData, null, 2));

    const updatedProduct = await holdedClient.updateProduct(params.id, productData);
    
    console.log(`✅ Producto actualizado en Holded: ${updatedProduct.name} (ID: ${updatedProduct.id})`);
    
    return NextResponse.json({
      success: true,
      product: updatedProduct,
      message: 'Producto actualizado exitosamente en Holded',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error(`❌ Error actualizando producto en Holded:`, error);
    
    return NextResponse.json({
      success: false,
      error: 'Error actualizando producto en Holded',
      details: String(error),
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}

// Eliminar un producto específico
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log(`📦 Eliminando producto de Holded con ID: ${params.id}`);
    
    await holdedClient.deleteProduct(params.id);
    
    console.log(`✅ Producto eliminado de Holded: ${params.id}`);
    
    return NextResponse.json({
      success: true,
      message: 'Producto eliminado exitosamente de Holded',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error(`❌ Error eliminando producto de Holded:`, error);
    
    return NextResponse.json({
      success: false,
      error: 'Error eliminando producto de Holded',
      details: String(error),
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}
