import { NextRequest, NextResponse } from 'next/server';
import { priceAnalysisService } from '@/lib/price-analysis';

// Obtener historial de precios de un producto
export async function GET(
  req: NextRequest,
  { params }: { params: { productId: string } }
) {
  try {
    console.log(`📊 Obteniendo historial de precios para producto: ${params.productId}`);
    
    const history = await priceAnalysisService.getProductPriceHistory(params.productId);
    
    console.log(`✅ Historial obtenido: ${history.length} entradas`);
    
    return NextResponse.json({
      success: true,
      history: history,
      count: history.length,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error(`❌ Error obteniendo historial de precios:`, error);
    
    return NextResponse.json({
      success: false,
      error: 'Error obteniendo historial de precios',
      details: String(error),
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}
