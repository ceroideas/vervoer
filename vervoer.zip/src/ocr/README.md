# Carpeta para lógica OCR
Aquí irá la lógica relacionada con el procesamiento OCR y utilidades asociadas. 