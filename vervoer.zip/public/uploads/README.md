# Carpeta para archivos subidos temporalmente
Aquí se almacenarán los archivos subidos por los usuarios de forma temporal para su procesamiento. 