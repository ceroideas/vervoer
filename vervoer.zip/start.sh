#!/bin/bash

# 🚀 Script de Inicio - Vervoer
# Este script inicia la aplicación en modo producción

echo "🚀 Iniciando Vervoer..."

# Verificar si Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "❌ Node.js no está instalado"
    exit 1
fi

# Verificar si npm está instalado
if ! command -v npm &> /dev/null; then
    echo "❌ npm no está instalado"
    exit 1
fi

# Verificar si PM2 está instalado
if ! command -v pm2 &> /dev/null; then
    echo "📦 Instalando PM2..."
    npm install -g pm2
fi

# Verificar si existe el archivo .env.local
if [ ! -f ".env.local" ]; then
    echo "⚠️  Archivo .env.local no encontrado"
    echo "📝 Creando archivo .env.local con configuración básica..."
    cat > .env.local << EOF
# Configuración de Vervoer
HOLDED_API_KEY=d2e52f08894f3322cdf43d4e58c0d909
OPENAI_API_KEY=tu-openai-api-key-aqui
NODE_ENV=production
EOF
    echo "✅ Archivo .env.local creado"
    echo "⚠️  IMPORTANTE: Edita el archivo .env.local con tus API keys reales"
fi

# Verificar si existe la carpeta .next (build)
if [ ! -d ".next" ]; then
    echo "🔨 Build no encontrado, compilando..."
    npm run build
    if [ $? -ne 0 ]; then
        echo "❌ Error en la compilación"
        exit 1
    fi
    echo "✅ Build completado"
fi

# Detener procesos PM2 existentes
echo "🛑 Deteniendo procesos PM2 existentes..."
pm2 stop vervoer 2>/dev/null || true
pm2 delete vervoer 2>/dev/null || true

# Iniciar la aplicación con PM2
echo "🚀 Iniciando aplicación con PM2..."
pm2 start ecosystem.config.js --env production

# Verificar que la aplicación esté corriendo
sleep 3
if pm2 list | grep -q "vervoer.*online"; then
    echo "✅ Aplicación iniciada correctamente"
    echo "📊 Estado de PM2:"
    pm2 list
    echo ""
    echo "🌐 La aplicación está disponible en:"
    echo "   - Local: http://localhost:3000"
    echo "   - Dominio: http://estamostrabajando.site"
    echo ""
    echo "📝 Comandos útiles:"
    echo "   - Ver logs: pm2 logs vervoer"
    echo "   - Reiniciar: pm2 restart vervoer"
    echo "   - Detener: pm2 stop vervoer"
    echo "   - Estado: pm2 status"
else
    echo "❌ Error al iniciar la aplicación"
    pm2 logs vervoer --lines 10
    exit 1
fi
